#include <stdio.h>
#include <stdlib.h>

int main(){
	int suma;
	int num;
		scanf("%d",&num);
	
	for(int i=0;i<n,i++){
		
		suma+=i;
	}
	printf("la suma de los primeros %d números es:\n")

		return 0;
}

