#include <stdio.h>
#include <stdlib.h>

int main(){
	int num;
	int suma;
	while(num > 0){
       		scanf("%d",&num);
      		suma+=num;
	}	
	else
	printf("La suma de los números ingresados es\n",suma);
