#include <stdio.h>
#include <stdlib.h>

int main(){
	float nota;
	printf("Introduce la nota:");
	scanf("%f",&nota);
	(nota >= 5) ? printf("Aprobado\n") : printf("Suspendido\n");

	return 0;
}

