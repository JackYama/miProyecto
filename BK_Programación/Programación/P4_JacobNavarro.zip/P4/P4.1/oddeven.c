#include <stdio.h>
#include <stdlib.h>
int main(){
	        printf("introduce un numero entero\n");
		                int numero;
				        scanf("%d",&numero);
					        if(numero %2 == 0){
							                printf("el numero es par\n");
									        }else{ printf("el numero es impar\n");
											        }
}
